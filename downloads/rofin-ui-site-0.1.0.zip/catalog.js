// Generated from catalog.json and the source examples by npm run build.
export default [
  {
    "id": "button",
    "title": "Button",
    "category": "Components",
    "description": "A clear next step, with four styles and three sizes.",
    "css": [
      "button"
    ],
    "js": [],
    "file": "examples/components/button.html",
    "notes": [
      "Use buttons for actions and links for navigation.",
      "Use the native disabled attribute on buttons. aria-disabled alone does not suppress link navigation.",
      "Icon-only buttons need an accessible name."
    ],
    "html": "<div class=\"rf-button-group\">\n  <button class=\"rf-button\" type=\"button\">Get started</button>\n  <button class=\"rf-button rf-button--outline\" type=\"button\">Learn more</button>\n  <button class=\"rf-button rf-button--ghost\" type=\"button\">Maybe later</button>\n  <button class=\"rf-button\" type=\"button\" disabled>Unavailable</button>\n</div>",
    "cssBytes": 1624
  },
  {
    "id": "card",
    "title": "Card",
    "category": "Components",
    "description": "A quiet surface for content, actions, and everything between.",
    "css": [
      "card",
      "button"
    ],
    "js": [],
    "file": "examples/components/card.html",
    "notes": [
      "The card is a container, not an interactive element. Put real links or buttons inside it.",
      "Use rf-card--interactive for a visual hover treatment."
    ],
    "html": "<article class=\"rf-card rf-card--elevated\">\n  <h3 class=\"rf-card__title\">A place for your next idea.</h3>\n  <p class=\"rf-card__description\">Give your content a little breathing room. Build on a simple, flexible surface.</p>\n  <div class=\"rf-card__footer\"><button class=\"rf-button\" type=\"button\">Explore possibilities</button></div>\n</article>",
    "cssBytes": 2517
  },
  {
    "id": "input",
    "title": "Input",
    "category": "Components",
    "description": "Native text fields with labels, help text, and error states.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/input.html",
    "notes": [
      "Always associate a visible label with the input.",
      "Set aria-invalid=\"true\" and aria-describedby to your error text when validation fails.",
      "Validation and submission remain your application’s responsibility."
    ],
    "html": "<div class=\"rf-stack\">\n  <div class=\"rf-field\">\n    <label class=\"rf-label\" for=\"input-name\">Your name</label>\n    <input class=\"rf-input\" id=\"input-name\" name=\"name\" autocomplete=\"name\" placeholder=\"Robin Francis\">\n  </div>\n  <div class=\"rf-field\">\n    <label class=\"rf-label\" for=\"input-email\">Email address</label>\n    <input class=\"rf-input\" id=\"input-email\" type=\"email\" autocomplete=\"email\" aria-describedby=\"email-help\" placeholder=\"you@example.com\">\n    <p class=\"rf-help\" id=\"email-help\">We’ll only use this to contact you about your account.</p>\n  </div>\n</div>",
    "cssBytes": 2360
  },
  {
    "id": "select",
    "title": "Select",
    "category": "Components",
    "description": "A native select that keeps platform keyboard and touch behavior.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/select.html",
    "notes": [
      "Native select styling varies slightly by browser and operating system.",
      "For simple autocomplete, consider native input with datalist before building a custom combobox."
    ],
    "html": "<div class=\"rf-field\">\n  <label class=\"rf-label\" for=\"select-team\">Team size</label>\n  <select class=\"rf-select\" id=\"select-team\" name=\"team\">\n    <option value=\"solo\">Just me</option><option value=\"small\">2–10 people</option><option value=\"large\">11–50 people</option>\n  </select>\n</div>",
    "cssBytes": 2360
  },
  {
    "id": "textarea",
    "title": "Textarea",
    "category": "Components",
    "description": "Room for a longer thought. Native resizing included.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/textarea.html",
    "notes": [
      "The field resizes vertically so its width stays inside the layout."
    ],
    "html": "<div class=\"rf-field\">\n  <label class=\"rf-label\" for=\"textarea-message\">Tell us about your project</label>\n  <textarea class=\"rf-textarea\" id=\"textarea-message\" name=\"message\" rows=\"4\" placeholder=\"Something wonderful starts here…\"></textarea>\n</div>",
    "cssBytes": 2360
  },
  {
    "id": "checkbox",
    "title": "Checkbox",
    "category": "Components",
    "description": "A native checkbox with a generous clickable label.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/checkbox.html",
    "notes": [
      "The wrapping label makes both the text and checkbox clickable."
    ],
    "html": "<label class=\"rf-check\"><input type=\"checkbox\" name=\"updates\" checked> Send me product updates</label>",
    "cssBytes": 2360
  },
  {
    "id": "radio",
    "title": "Radio group",
    "category": "Components",
    "description": "Mutually exclusive choices, grouped with native semantics.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/radio.html",
    "notes": [
      "Use the same name on the radio inputs.",
      "A fieldset and legend communicate the group’s purpose."
    ],
    "html": "<fieldset class=\"rf-fieldset\">\n  <legend>Choose a workspace</legend>\n  <div class=\"rf-stack\" style=\"--rf-gap: .25rem\">\n    <label class=\"rf-check\"><input type=\"radio\" name=\"workspace\" value=\"personal\" checked> Personal</label>\n    <label class=\"rf-check\"><input type=\"radio\" name=\"workspace\" value=\"team\"> Team</label>\n  </div>\n</fieldset>",
    "cssBytes": 2360
  },
  {
    "id": "switch",
    "title": "Switch",
    "category": "Components",
    "description": "A small on/off control built from a real checkbox.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/switch.html",
    "notes": [
      "The browser owns checked state and Space key behavior.",
      "Keep the label stable when toggled; it names the setting, not the current state."
    ],
    "html": "<label class=\"rf-check\"><input class=\"rf-switch\" type=\"checkbox\" role=\"switch\" name=\"notifications\" checked> Enable notifications</label>",
    "cssBytes": 2360
  },
  {
    "id": "range",
    "title": "Range",
    "category": "Components",
    "description": "A slider that works with keyboard, mouse, and touch.",
    "css": [
      "form"
    ],
    "js": [],
    "file": "examples/components/range.html",
    "notes": [
      "Arrow keys adjust the value. Home and End are provided by the browser.",
      "If you display the value separately, keep that display synchronized in your app."
    ],
    "html": "<div class=\"rf-field\">\n  <label class=\"rf-label\" for=\"range-volume\">Volume</label>\n  <input class=\"rf-range\" type=\"range\" id=\"range-volume\" min=\"0\" max=\"100\" value=\"65\">\n</div>",
    "cssBytes": 2360
  },
  {
    "id": "accordion",
    "title": "Accordion",
    "category": "Components",
    "description": "Expandable content using native details and summary.",
    "css": [
      "accordion"
    ],
    "js": [],
    "file": "examples/components/accordion.html",
    "notes": [
      "No JavaScript is required.",
      "Use details name=\"your-group\" for exclusive opening in browsers supporting grouped details."
    ],
    "html": "<div class=\"rf-accordion\">\n  <details open><summary>Does this need a framework?</summary><div class=\"rf-accordion__content\"><p>No. Use plain HTML and CSS. Add small JavaScript modules only for the interactions you need.</p></div></details>\n  <details><summary>Can I change the colors?</summary><div class=\"rf-accordion__content\"><p>Yes. Override the --rf-* design tokens to make it yours.</p></div></details>\n  <details><summary>What’s the license?</summary><div class=\"rf-accordion__content\"><p>MIT. Use it in personal or commercial projects and retain the license notice.</p></div></details>\n</div>",
    "cssBytes": 710
  },
  {
    "id": "tabs",
    "title": "Tabs",
    "category": "Components",
    "description": "Organize nearby content with keyboard navigation and native buttons.",
    "css": [
      "tabs"
    ],
    "js": [
      "tabs"
    ],
    "file": "examples/components/tabs.html",
    "notes": [
      "Left/Right, Home, and End move between tabs. Vertical tablists use Up/Down.",
      "Set data-rf-activation=\"manual\" to activate only on Enter, Space, or click.",
      "Use equal numbers of tabs and panels. aria-controls can map them explicitly.",
      "Without JS, all panels remain visible. After changing a tabset’s internal structure, destroy and initialize that root again."
    ],
    "html": "<div class=\"rf-tabs\" data-rf-tabs>\n  <div role=\"tablist\" aria-label=\"Workspace views\">\n    <button type=\"button\" role=\"tab\" aria-selected=\"true\">Overview</button>\n    <button type=\"button\" role=\"tab\">Activity</button>\n    <button type=\"button\" role=\"tab\">Settings</button>\n  </div>\n  <div role=\"tabpanel\"><h3>Your workspace, at a glance.</h3><p class=\"rf-muted\">Keep your projects and people together.</p></div>\n  <div role=\"tabpanel\"><h3>A little progress, every day.</h3><p class=\"rf-muted\">Your latest work appears here.</p></div>\n  <div role=\"tabpanel\"><h3>Make yourself at home.</h3><p class=\"rf-muted\">Customize the workspace to fit your flow.</p></div>\n</div>",
    "cssBytes": 873
  },
  {
    "id": "dropdown",
    "title": "Dropdown menu",
    "category": "Components",
    "description": "A native popover enhanced with focus, arrows, and typeahead.",
    "css": [
      "dropdown",
      "button"
    ],
    "js": [
      "dropdown"
    ],
    "file": "examples/components/dropdown.html",
    "notes": [
      "Requires native Popover API support.",
      "Arrow keys, Home/End, and typing move focus. Escape closes the menu.",
      "Use menu roles for application actions. For ordinary website navigation, use nav and links instead.",
      "Attach your application behavior to the menu item buttons."
    ],
    "html": "<div data-rf-dropdown>\n  <button class=\"rf-button rf-button--outline\" type=\"button\" popovertarget=\"actions-menu\">Project actions <span aria-hidden=\"true\">⌄</span></button>\n  <div class=\"rf-menu\" id=\"actions-menu\" popover role=\"menu\" aria-label=\"Project actions\">\n    <button type=\"button\" role=\"menuitem\">Edit project</button>\n    <button type=\"button\" role=\"menuitem\">Duplicate</button>\n    <hr class=\"rf-menu__separator\" role=\"separator\">\n    <button type=\"button\" role=\"menuitem\">Archive project</button>\n  </div>\n</div>",
    "cssBytes": 2620
  },
  {
    "id": "dialog",
    "title": "Dialog",
    "category": "Components",
    "description": "A modal with browser-managed focus trapping and Escape behavior.",
    "css": [
      "dialog",
      "button"
    ],
    "js": [
      "dialog"
    ],
    "file": "examples/components/dialog.html",
    "notes": [
      "Label every dialog with aria-labelledby or aria-label.",
      "The browser traps focus and closes on Escape.",
      "Backdrop clicks dismiss only when data-rf-backdrop-close is present.",
      "You can call showModal() directly instead of using the data attributes."
    ],
    "html": "<button class=\"rf-button\" type=\"button\" data-rf-dialog-open=\"welcome-dialog\">Open dialog</button>\n<dialog class=\"rf-dialog\" id=\"welcome-dialog\" aria-labelledby=\"welcome-title\" aria-describedby=\"welcome-description\" data-rf-backdrop-close>\n  <h2 class=\"rf-dialog__title\" id=\"welcome-title\">A fresh start.</h2>\n  <p class=\"rf-muted\" id=\"welcome-description\">Everything you need to build something thoughtful.</p>\n  <div class=\"rf-dialog__actions\"><button class=\"rf-button\" type=\"button\" data-rf-dialog-close autofocus>Sounds good</button></div>\n</dialog>",
    "cssBytes": 2390
  },
  {
    "id": "drawer",
    "title": "Drawer",
    "category": "Components",
    "description": "The native dialog, arranged as a full-height side panel.",
    "css": [
      "dialog",
      "form",
      "button"
    ],
    "js": [
      "dialog"
    ],
    "file": "examples/components/drawer.html",
    "notes": [
      "Uses the same native dialog behavior and API.",
      "This panel is a modal. For a persistent sidebar, use the Navigation component."
    ],
    "html": "<button class=\"rf-button rf-button--outline\" type=\"button\" data-rf-dialog-open=\"settings-drawer\">Workspace settings</button>\n<dialog class=\"rf-dialog rf-dialog--drawer\" id=\"settings-drawer\" aria-labelledby=\"drawer-title\">\n  <h2 class=\"rf-dialog__title\" id=\"drawer-title\">Workspace settings</h2>\n  <p class=\"rf-muted\">Give your workspace a name that feels like you.</p>\n  <div class=\"rf-field\"><label class=\"rf-label\" for=\"drawer-name\">Workspace name</label><input class=\"rf-input\" id=\"drawer-name\" value=\"Studio\" autofocus></div>\n  <div class=\"rf-dialog__actions\"><button class=\"rf-button\" type=\"button\" data-rf-dialog-close>Done</button></div>\n</dialog>",
    "cssBytes": 4750
  },
  {
    "id": "tooltip",
    "title": "Tooltip",
    "category": "Components",
    "description": "A short hint on hover or focus, dismissible with Escape.",
    "css": [
      "tooltip",
      "button"
    ],
    "js": [
      "tooltip"
    ],
    "file": "examples/components/tooltip.html",
    "notes": [
      "Use aria-describedby to connect the hint to its trigger.",
      "Never put essential instructions or interactive controls only inside a tooltip.",
      "Tooltip positioning is local to its wrapper; avoid clipped containers and viewport edges.",
      "JS adds Escape dismissal; hover and focus display work with CSS alone."
    ],
    "html": "<span class=\"rf-tooltip\">\n  <button class=\"rf-button rf-button--outline\" type=\"button\" aria-describedby=\"shortcut-hint\">Save changes</button>\n  <span class=\"rf-tooltip__content\" id=\"shortcut-hint\" role=\"tooltip\">Save your current workspace settings</span>\n</span>",
    "cssBytes": 2343
  },
  {
    "id": "toast",
    "title": "Toast",
    "category": "Components",
    "description": "Text-only notifications with a dismiss button and paused timers.",
    "css": [
      "toast",
      "button"
    ],
    "js": [
      "toast"
    ],
    "file": "examples/components/toast.html",
    "notes": [
      "Messages are treated as text, never HTML.",
      "duration: 0 keeps the notification until dismissed. Default: 5000 ms.",
      "Hover, keyboard focus, and hidden browser tabs pause the timer.",
      "Do not rely on a timed toast as the only source of critical information.",
      "Toasts are outside modal dialogs; put important modal feedback inside the dialog."
    ],
    "sampleJS": "document.querySelector('[data-demo-toast]').addEventListener('click', () => {\n  toast('Your changes are saved.', { title: 'All set', variant: 'success', duration: 5000 });\n});",
    "html": "<button class=\"rf-button\" type=\"button\" data-demo-toast>Show notification</button>",
    "cssBytes": 2613
  },
  {
    "id": "badge",
    "title": "Badge",
    "category": "Components",
    "description": "Compact labels for status, metadata, and little milestones.",
    "css": [
      "badge"
    ],
    "js": [],
    "file": "examples/components/badge.html",
    "notes": [
      "Always communicate status with text; color alone isn’t enough."
    ],
    "html": "<div class=\"rf-cluster\">\n  <span class=\"rf-badge\"><span class=\"rf-badge__dot\" aria-hidden=\"true\"></span> New release</span>\n  <span class=\"rf-badge\" data-variant=\"success\">Published</span>\n  <span class=\"rf-badge\" data-variant=\"warning\">Draft</span>\n  <span class=\"rf-badge\" data-variant=\"danger\">Needs attention</span>\n</div>",
    "cssBytes": 798
  },
  {
    "id": "avatar",
    "title": "Avatar",
    "category": "Components",
    "description": "Initials or images, alone or in a small team.",
    "css": [
      "avatar"
    ],
    "js": [],
    "file": "examples/components/avatar.html",
    "notes": [
      "Give standalone initials a name using role=\"img\" and aria-label.",
      "For an image, use meaningful alt text or alt=\"\" when the adjacent text already identifies the person."
    ],
    "html": "<div class=\"rf-cluster\">\n  <span class=\"rf-avatar\" role=\"img\" aria-label=\"Robin Francis\">RF</span>\n  <div class=\"rf-avatar-group\" aria-label=\"Project team\">\n    <span class=\"rf-avatar\" role=\"img\" aria-label=\"Alex Morgan\">AM</span>\n    <span class=\"rf-avatar\" role=\"img\" aria-label=\"Jamie Lee\">JL</span>\n    <span class=\"rf-avatar\" role=\"img\" aria-label=\"Three more teammates\">+3</span>\n  </div>\n</div>",
    "cssBytes": 561
  },
  {
    "id": "alert",
    "title": "Alert",
    "category": "Components",
    "description": "Persistent feedback with a title, message, and semantic color.",
    "css": [
      "alert"
    ],
    "js": [],
    "file": "examples/components/alert.html",
    "notes": [
      "Use role=\"status\" when inserting a nonurgent update dynamically.",
      "Use role=\"alert\" for urgent errors, not for every static message."
    ],
    "html": "<div class=\"rf-alert\" data-variant=\"success\">\n  <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" aria-hidden=\"true\"><path d=\"m5 12 4 4L19 6\"/></svg>\n  <div><strong class=\"rf-alert__title\">You’re ready to go.</strong><p>Your workspace has been created. Time to make something great.</p></div>\n</div>",
    "cssBytes": 724
  },
  {
    "id": "breadcrumb",
    "title": "Breadcrumb",
    "category": "Components",
    "description": "Show the route back using ordinary navigation links.",
    "css": [
      "breadcrumb"
    ],
    "js": [],
    "file": "examples/components/breadcrumb.html",
    "notes": [
      "Replace the example fragment links with your application’s real URLs.",
      "aria-current=\"page\" marks the current location."
    ],
    "html": "<nav class=\"rf-breadcrumb\" aria-label=\"Breadcrumb\">\n  <ol><li><a href=\"#home\">Home</a></li><li><a href=\"#projects\">Projects</a></li><li><span aria-current=\"page\">Rofin UI</span></li></ol>\n</nav>",
    "cssBytes": 414
  },
  {
    "id": "pagination",
    "title": "Pagination",
    "category": "Components",
    "description": "A clear way through a longer list. Navigation stays native.",
    "css": [
      "pagination"
    ],
    "js": [],
    "file": "examples/components/pagination.html",
    "notes": [
      "Your server or app owns page selection and result loading.",
      "Give previous/next controls meaningful accessible names."
    ],
    "html": "<nav class=\"rf-pagination\" aria-label=\"Results pages\">\n  <a href=\"?page=1\" aria-label=\"Previous page\">←</a>\n  <a href=\"?page=1\" aria-label=\"Page 1\">1</a><a href=\"?page=2\" aria-label=\"Page 2\" aria-current=\"page\">2</a><a href=\"?page=3\" aria-label=\"Page 3\">3</a>\n  <span class=\"rf-pagination__ellipsis\" aria-hidden=\"true\">…</span><a href=\"?page=10\" aria-label=\"Page 10\">10</a><a href=\"?page=3\" aria-label=\"Next page\">→</a>\n</nav>",
    "cssBytes": 676
  },
  {
    "id": "table",
    "title": "Table",
    "category": "Components",
    "description": "Readable native tables in a horizontal scroll container.",
    "css": [
      "table",
      "badge"
    ],
    "js": [],
    "file": "examples/components/table.html",
    "notes": [
      "Native table semantics are retained. Use caption, th, and scope.",
      "The focusable wrapper makes horizontal scrolling available by keyboard.",
      "Sorting, filtering, and virtualization are not part of this component."
    ],
    "html": "<div class=\"rf-table-wrap\" tabindex=\"0\" role=\"region\" aria-label=\"Projects table\">\n  <table class=\"rf-table\"><caption>Your latest projects</caption>\n    <thead><tr><th scope=\"col\">Project</th><th scope=\"col\">Status</th><th scope=\"col\">Updated</th></tr></thead>\n    <tbody><tr><th scope=\"row\">Studio website</th><td><span class=\"rf-badge\" data-variant=\"success\">Published</span></td><td>Today</td></tr>\n    <tr><th scope=\"row\">Component library</th><td><span class=\"rf-badge\" data-variant=\"warning\">In progress</span></td><td>Yesterday</td></tr></tbody>\n  </table>\n</div>",
    "cssBytes": 1461
  },
  {
    "id": "progress",
    "title": "Progress",
    "category": "Components",
    "description": "A native progress bar for an operation with a known total.",
    "css": [
      "progress"
    ],
    "js": [],
    "file": "examples/components/progress.html",
    "notes": [
      "Update the native value attribute as work progresses.",
      "Omit value for indeterminate progress; its appearance is browser-dependent."
    ],
    "html": "<div class=\"rf-field\"><label class=\"rf-label\" for=\"project-progress\">Project completion — 72%</label><progress class=\"rf-progress\" id=\"project-progress\" value=\"72\" max=\"100\">72%</progress></div>",
    "cssBytes": 679
  },
  {
    "id": "meter",
    "title": "Meter",
    "category": "Components",
    "description": "A native measurement inside a known range.",
    "css": [
      "progress"
    ],
    "js": [],
    "file": "examples/components/meter.html",
    "notes": [
      "Meter represents a measurement such as storage usage. Progress represents completion of work.",
      "Meter colors and rendering may vary by browser."
    ],
    "html": "<div class=\"rf-field\"><label class=\"rf-label\" for=\"storage-meter\">Storage used — 6 of 10 GB</label><meter class=\"rf-meter\" id=\"storage-meter\" value=\"6\" min=\"0\" max=\"10\" low=\"3\" high=\"8\" optimum=\"2\">6 GB</meter></div>",
    "cssBytes": 679
  },
  {
    "id": "spinner",
    "title": "Spinner",
    "category": "Components",
    "description": "A small loading indicator with a text alternative.",
    "css": [
      "loading"
    ],
    "js": [],
    "file": "examples/components/spinner.html",
    "notes": [
      "Include meaningful status text; the spinning shape is decorative.",
      "Reduced-motion preferences stop the animation."
    ],
    "html": "<span role=\"status\" class=\"rf-cluster\"><span class=\"rf-spinner\" aria-hidden=\"true\"></span><span>Loading your workspace…</span></span>",
    "cssBytes": 615
  },
  {
    "id": "skeleton",
    "title": "Skeleton",
    "category": "Components",
    "description": "A quiet placeholder while content is on its way.",
    "css": [
      "loading"
    ],
    "js": [],
    "file": "examples/components/skeleton.html",
    "notes": [
      "Hide decorative placeholders from assistive technology and provide one loading status.",
      "Remove the status when your content arrives."
    ],
    "html": "<div class=\"rf-stack\" role=\"status\" aria-label=\"Loading profile\">\n  <div class=\"rf-cluster\" aria-hidden=\"true\"><span class=\"rf-skeleton rf-skeleton--circle\"></span><div class=\"rf-stack\" style=\"flex:1; --rf-gap:.5rem\"><span class=\"rf-skeleton\" style=\"width:60%\"></span><span class=\"rf-skeleton\" style=\"width:40%\"></span></div></div>\n  <span class=\"rf-skeleton\" aria-hidden=\"true\"></span><span class=\"rf-skeleton\" aria-hidden=\"true\" style=\"width:80%\"></span>\n</div>",
    "cssBytes": 615
  },
  {
    "id": "upload",
    "title": "File input",
    "category": "Components",
    "description": "A real file picker with optional selected-file details.",
    "css": [
      "upload",
      "form"
    ],
    "js": [
      "upload"
    ],
    "file": "examples/components/upload.html",
    "notes": [
      "JS only lists selected file names and sizes.",
      "Uploads, MIME checks, limits, and server-side validation belong to your application.",
      "File names are inserted as text, not HTML."
    ],
    "html": "<div class=\"rf-upload\" data-rf-upload>\n  <label class=\"rf-label\" for=\"project-files\">Add files to your project</label>\n  <p class=\"rf-help\" id=\"files-help\">Choose one or more files. This demo lists them locally; it does not upload them.</p>\n  <input id=\"project-files\" type=\"file\" multiple aria-describedby=\"files-help\">\n  <ul class=\"rf-upload__files\" data-rf-file-list aria-live=\"polite\"></ul>\n</div>",
    "cssBytes": 3049
  },
  {
    "id": "navigation",
    "title": "Navigation",
    "category": "Components",
    "description": "Simple horizontal or vertical navigation using real links.",
    "css": [
      "navigation"
    ],
    "js": [],
    "file": "examples/components/navigation.html",
    "notes": [
      "Add rf-nav--vertical for sidebar navigation.",
      "Use aria-current=\"page\" only on the current destination."
    ],
    "html": "<nav class=\"rf-nav\" aria-label=\"Workspace navigation\"><a href=\"#overview\" aria-current=\"page\">Overview</a><a href=\"#projects\">Projects</a><a href=\"#team\">Team</a><a href=\"#settings\">Settings</a></nav>",
    "cssBytes": 543
  },
  {
    "id": "empty-state",
    "title": "Empty state",
    "category": "Components",
    "description": "Give an empty view a useful next step.",
    "css": [
      "empty-state",
      "button"
    ],
    "js": [],
    "file": "examples/components/empty-state.html",
    "notes": [
      "Explain why the view is empty and offer a relevant next action."
    ],
    "html": "<div class=\"rf-empty\">\n  <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" aria-hidden=\"true\"><rect x=\"3\" y=\"5\" width=\"18\" height=\"16\" rx=\"3\"/><path d=\"M8 3v4m8-4v4M3 11h18m-9 3v4m-2-2h4\"/></svg>\n  <h3>A clean slate.</h3><p>No projects yet. Your first idea is a good place to start.</p><button class=\"rf-button\" type=\"button\">Create a project</button>\n</div>",
    "cssBytes": 2033
  },
  {
    "id": "layout",
    "title": "Layout",
    "category": "Components",
    "description": "Responsive grids, stacks, and clusters without a utility framework.",
    "css": [
      "layout",
      "card"
    ],
    "js": [],
    "file": "examples/components/layout.html",
    "notes": [
      "rf-grid adapts to its container. --rf-column sets the preferred minimum column width.",
      "rf-stack arranges content vertically; rf-cluster wraps a horizontal row.",
      "Override --rf-gap locally for consistent spacing."
    ],
    "html": "<div class=\"rf-grid\" style=\"--rf-column: 10rem; --rf-gap: .75rem\">\n  <div class=\"rf-card\">A little structure.</div><div class=\"rf-card\">Room to breathe.</div><div class=\"rf-card\">Made to adapt.</div>\n</div>",
    "cssBytes": 1958
  },
  {
    "id": "dot-grid",
    "title": "Dot grid",
    "category": "Effects",
    "description": "A repeating background drawn entirely in CSS.",
    "css": [
      "effects",
      "card"
    ],
    "js": [],
    "file": "examples/components/dot-grid.html",
    "notes": [
      "Decorative background only. Keep text contrast readable over it."
    ],
    "html": "<div class=\"rf-card rf-dot-grid rf-center\" style=\"padding:3rem\"><h3>Small details. Big character.</h3><p class=\"rf-muted\">A little texture, without an image.</p></div>",
    "cssBytes": 2526
  },
  {
    "id": "gradient-text",
    "title": "Gradient text",
    "category": "Effects",
    "description": "A restrained two-color treatment for a headline.",
    "css": [
      "effects"
    ],
    "js": [],
    "file": "examples/components/gradient-text.html",
    "notes": [
      "Use sparingly and check contrast across the full gradient.",
      "Forced-color mode falls back to normal text."
    ],
    "html": "<h2 class=\"rf-gradient-text\" style=\"font-size:clamp(2rem,6vw,3.5rem); margin:0; line-height:1.1; letter-spacing:-.05em\">Make something<br>worth opening.</h2>",
    "cssBytes": 1633
  },
  {
    "id": "hover-lift",
    "title": "Hover lift",
    "category": "Effects",
    "description": "A small lift for interactive cards, with reduced-motion support.",
    "css": [
      "effects",
      "card",
      "button"
    ],
    "js": [],
    "file": "examples/components/hover-lift.html",
    "notes": [
      "Hover styling is decorative. Put a real interactive control inside the card.",
      "Reduced-motion mode disables movement."
    ],
    "html": "<article class=\"rf-card rf-hover-lift\"><h3 class=\"rf-card__title\">A little elevation.</h3><p class=\"rf-card__description\">Hover over this card to see it move.</p><div class=\"rf-card__footer\"><button class=\"rf-button rf-button--outline\" type=\"button\">Explore</button></div></article>",
    "cssBytes": 4150
  },
  {
    "id": "spotlight",
    "title": "Spotlight",
    "category": "Effects",
    "description": "A subtle pointer-following highlight, updated once per animation frame.",
    "css": [
      "effects",
      "card"
    ],
    "js": [
      "effects"
    ],
    "file": "examples/components/spotlight.html",
    "notes": [
      "Opt-in: import initEffects from the separate effects module.",
      "No pointer tracking on touch devices or in reduced-motion mode.",
      "The card stays usable without JavaScript."
    ],
    "html": "<article class=\"rf-card\" data-rf-spotlight style=\"padding:3rem\"><h3 class=\"rf-card__title\">Follow your curiosity.</h3><p class=\"rf-card__description\">Move your pointer across this surface.</p></article>",
    "cssBytes": 2526
  },
  {
    "id": "reveal",
    "title": "Reveal",
    "category": "Effects",
    "description": "A one-time entrance as content comes into view.",
    "css": [
      "effects",
      "card"
    ],
    "js": [
      "effects"
    ],
    "file": "examples/components/reveal.html",
    "notes": [
      "Content is visible without JS.",
      "IntersectionObserver reveals each element once. Reduced-motion mode shows content immediately.",
      "Call initEffects for each new subtree and its returned teardown before removing it."
    ],
    "html": "<div class=\"rf-grid\" style=\"--rf-column:10rem\"><article class=\"rf-card\" data-rf-reveal>Start small.</article><article class=\"rf-card\" data-rf-reveal>Build thoughtfully.</article><article class=\"rf-card\" data-rf-reveal>Keep it light.</article></div>",
    "cssBytes": 2526
  },
  {
    "id": "shimmer",
    "title": "Shimmer",
    "category": "Effects",
    "description": "A single sheen on hover or focus, not a continuous animation.",
    "css": [
      "effects",
      "button"
    ],
    "js": [],
    "file": "examples/components/shimmer.html",
    "notes": [
      "Runs only on interaction. Reduced-motion mode disables the effect."
    ],
    "html": "<button class=\"rf-button rf-button--large rf-shimmer\" type=\"button\">Make your next move <span aria-hidden=\"true\">→</span></button>",
    "cssBytes": 3257
  },
  {
    "id": "hero",
    "title": "Split hero",
    "category": "Sections",
    "description": "An introduction with a clear promise and a small product preview.",
    "css": [
      "sections",
      "card",
      "button",
      "badge",
      "progress"
    ],
    "js": [],
    "file": "sections/hero.html",
    "notes": [
      "Replace placeholder copy and links with your product’s real content.",
      "Include the core stylesheet and the optional sections stylesheet."
    ],
    "html": "<section class=\"rf-section rf-container rf-hero\">\n  <div><span class=\"rf-badge\">A quieter way to build</span><h1>Less overhead.<br>More possibility.</h1><p class=\"rf-section__intro\">A thoughtful workspace for your ideas, your team, and the work that matters.</p><div class=\"rf-cluster\"><a class=\"rf-button\" href=\"#get-started\">Start building</a><a class=\"rf-button rf-button--outline\" href=\"#features\">See how it works</a></div></div>\n  <div class=\"rf-hero__visual\"><article class=\"rf-card\"><span class=\"rf-eyebrow\">Your next chapter</span><h2 class=\"rf-card__title\" style=\"margin-top:1rem\">Website launch</h2><p class=\"rf-card__description\">A little progress, every day.</p><div style=\"margin-top:1.5rem\"><label class=\"rf-help\" for=\"hero-progress\">72% complete</label><progress class=\"rf-progress\" id=\"hero-progress\" max=\"100\" value=\"72\">72%</progress></div></article></div>\n</section>",
    "cssBytes": 5640
  },
  {
    "id": "features",
    "title": "Feature grid",
    "category": "Sections",
    "description": "Three simple benefits with room for real explanations.",
    "css": [
      "sections",
      "card"
    ],
    "js": [],
    "file": "sections/features.html",
    "notes": [
      "This responsive layout uses the shared rf-grid utility."
    ],
    "html": "<section class=\"rf-section rf-container\" id=\"features\"><p class=\"rf-eyebrow\">The essentials, considered</p><h2 class=\"rf-section__heading\">Everything you need.<br>Space for what’s next.</h2><p class=\"rf-section__intro\">A foundation that gets out of your way.</p><div class=\"rf-grid\"><article class=\"rf-card\"><h3 class=\"rf-card__title\">Start with HTML</h3><p class=\"rf-card__description\">Use familiar elements and keep your content readable from the first response.</p></article><article class=\"rf-card\"><h3 class=\"rf-card__title\">Make it yours</h3><p class=\"rf-card__description\">Change a few design tokens to bring your own colors, spacing, and character.</p></article><article class=\"rf-card\"><h3 class=\"rf-card__title\">Load what you use</h3><p class=\"rf-card__description\">Pick individual components and keep optional effects separate.</p></article></div></section>",
    "cssBytes": 2539
  },
  {
    "id": "bento",
    "title": "Bento grid",
    "category": "Sections",
    "description": "An asymmetric feature layout that becomes a stack on small screens.",
    "css": [
      "sections",
      "card",
      "badge",
      "progress"
    ],
    "js": [],
    "file": "sections/bento.html",
    "notes": [
      "The first item spans two columns on larger screens.",
      "The reading order stays the same as the DOM order."
    ],
    "html": "<section class=\"rf-section rf-container\"><p class=\"rf-eyebrow\">Built for real work</p><h2 class=\"rf-section__heading\">Small pieces.<br>Good things together.</h2><div class=\"rf-bento\"><article class=\"rf-card\"><span class=\"rf-badge\" data-variant=\"success\">In your flow</span><h3>One place for the whole picture.</h3><p class=\"rf-muted\">Bring your projects, plans, and people into a workspace that feels natural.</p></article><article class=\"rf-card\"><p class=\"rf-eyebrow\">Momentum</p><p class=\"rf-stat\">72%</p><label class=\"rf-help\" for=\"bento-progress\">Project complete</label><progress class=\"rf-progress\" id=\"bento-progress\" max=\"100\" value=\"72\">72%</progress></article><article class=\"rf-card\"><h3>Made to adapt.</h3><p class=\"rf-muted\">A responsive foundation, from pocket to desktop.</p></article><article class=\"rf-card\"><h3>Your own character.</h3><p class=\"rf-muted\">Bring your colors and your perspective.</p></article><article class=\"rf-card\"><h3>Room to grow.</h3><p class=\"rf-muted\">Start with one component. Compose something larger.</p></article></div></section>",
    "cssBytes": 4016
  },
  {
    "id": "pricing",
    "title": "Pricing",
    "category": "Sections",
    "description": "Three transparent plans, with one clearly highlighted.",
    "css": [
      "sections",
      "card",
      "button",
      "badge"
    ],
    "js": [],
    "file": "sections/pricing.html",
    "notes": [
      "Prices and features are sample content. Replace them before publishing.",
      "Use real purchase or contact destinations. This section does not process payments."
    ],
    "html": "<section class=\"rf-section rf-container rf-pricing\"><p class=\"rf-eyebrow\">Simple plans</p><h2 class=\"rf-section__heading\">A good fit, at every stage.</h2><p class=\"rf-section__intro\">Illustrative plans for your own product. Rofin UI itself is free and MIT licensed.</p><div class=\"rf-grid\"><article class=\"rf-card\"><h3 class=\"rf-card__title\">Personal</h3><p class=\"rf-muted\">A place to begin.</p><p class=\"rf-price\">$0 <small>/ month</small></p><ul><li>One workspace</li><li>Personal projects</li><li>Community support</li></ul><a class=\"rf-button rf-button--outline\" href=\"#get-started\">Start free</a></article><article class=\"rf-card rf-pricing__featured\"><span class=\"rf-badge\">For growing teams</span><h3 style=\"margin-bottom:0\">Studio</h3><p class=\"rf-muted\">Space to build together.</p><p class=\"rf-price\">$19 <small>/ month</small></p><ul><li>Unlimited projects</li><li>Team collaboration</li><li>Priority support</li></ul><a class=\"rf-button\" href=\"#get-started\">Choose Studio</a></article><article class=\"rf-card\"><h3 class=\"rf-card__title\">Organization</h3><p class=\"rf-muted\">Room for the bigger picture.</p><p class=\"rf-price\">Let’s talk</p><ul><li>Multiple workspaces</li><li>Custom onboarding</li><li>Dedicated support</li></ul><a class=\"rf-button rf-button--outline\" href=\"#contact\">Contact us</a></article></div></section>",
    "cssBytes": 4961
  },
  {
    "id": "testimonials",
    "title": "Testimonials",
    "category": "Sections",
    "description": "A compact quote layout with clear attribution.",
    "css": [
      "sections",
      "card",
      "avatar"
    ],
    "js": [],
    "file": "sections/testimonials.html",
    "notes": [
      "These are fictional demonstration quotes, not endorsements.",
      "Use figure, blockquote, and figcaption for quote attribution."
    ],
    "html": "<section class=\"rf-section rf-container\"><p class=\"rf-eyebrow\">A few kind words</p><h2 class=\"rf-section__heading\">Good work feels lighter.</h2><p class=\"rf-section__intro\">Sample testimonials for layout demonstration. Replace these with permissioned customer quotes.</p><div class=\"rf-grid\"><figure class=\"rf-card rf-testimonial\" style=\"margin:0\"><blockquote>“The right foundation makes room for the work that matters.”</blockquote><figcaption><span class=\"rf-avatar\" aria-hidden=\"true\">AM</span><div><strong>Alex Morgan</strong><br><span class=\"rf-muted\">Sample designer</span></div></figcaption></figure><figure class=\"rf-card rf-testimonial\" style=\"margin:0\"><blockquote>“Small, thoughtful pieces that come together beautifully.”</blockquote><figcaption><span class=\"rf-avatar\" aria-hidden=\"true\">JL</span><div><strong>Jamie Lee</strong><br><span class=\"rf-muted\">Sample developer</span></div></figcaption></figure></div></section>",
    "cssBytes": 3100
  },
  {
    "id": "stats",
    "title": "Stats",
    "category": "Sections",
    "description": "A tidy row of numbers with the context to make them useful.",
    "css": [
      "sections",
      "card"
    ],
    "js": [],
    "file": "sections/stats.html",
    "notes": [
      "Numbers are sample workspace data, not measured Rofin performance claims."
    ],
    "html": "<section class=\"rf-section rf-container\" aria-label=\"Sample workspace statistics\"><p class=\"rf-eyebrow\">A little perspective</p><h2 class=\"rf-section__heading\">Your workspace, in numbers.</h2><div class=\"rf-grid\"><article class=\"rf-card\"><p class=\"rf-stat\">24</p><p class=\"rf-muted\">Active projects</p></article><article class=\"rf-card\"><p class=\"rf-stat\">8</p><p class=\"rf-muted\">Teammates</p></article><article class=\"rf-card\"><p class=\"rf-stat\">72%</p><p class=\"rf-muted\">Current milestone</p></article></div></section>",
    "cssBytes": 2539
  },
  {
    "id": "faq",
    "title": "FAQ",
    "category": "Sections",
    "description": "A complete frequently asked questions section without JavaScript.",
    "css": [
      "sections",
      "accordion"
    ],
    "js": [],
    "file": "sections/faq.html",
    "notes": [
      "Built entirely from the native accordion and section styles."
    ],
    "html": "<section class=\"rf-section rf-container\"><p class=\"rf-eyebrow\">A few answers</p><h2 class=\"rf-section__heading\">Wondering about something?</h2><div class=\"rf-accordion\"><details><summary>Can I use this commercially?</summary><div class=\"rf-accordion__content\"><p>Yes. Rofin UI is MIT licensed. Retain the license and copyright notice when redistributing the code.</p></div></details><details><summary>Does it work with my stack?</summary><div class=\"rf-accordion__content\"><p>The foundation is HTML, CSS, and vanilla JavaScript. No framework is required.</p></div></details><details><summary>Can I pick just one component?</summary><div class=\"rf-accordion__content\"><p>Yes. Load the design tokens and the individual component styles or behavior you need.</p></div></details></div></section>",
    "cssBytes": 2356
  },
  {
    "id": "cta",
    "title": "Call to action",
    "category": "Sections",
    "description": "One promise and one clear next step.",
    "css": [
      "sections",
      "card",
      "button"
    ],
    "js": [],
    "file": "sections/cta.html",
    "notes": [
      "Connect the link to your product’s actual signup or contact destination."
    ],
    "html": "<section class=\"rf-section rf-container\" id=\"get-started\"><div class=\"rf-card rf-center\" style=\"padding:3rem 1.5rem\"><p class=\"rf-eyebrow\">Your next chapter</p><h2 class=\"rf-section__heading\" style=\"margin-inline:auto\">Make room for a good idea.</h2><p class=\"rf-section__intro\" style=\"margin-inline:auto\">Start small. Build something that feels like you.</p><a class=\"rf-button rf-button--large\" href=\"#contact\">Let’s get started <span aria-hidden=\"true\">→</span></a></div></section>",
    "cssBytes": 4163
  },
  {
    "id": "footer",
    "title": "Footer",
    "category": "Sections",
    "description": "A compact footer with a brand, useful links, and a copyright line.",
    "css": [
      "sections",
      "navigation"
    ],
    "js": [],
    "file": "sections/footer.html",
    "notes": [
      "Replace the brand, year, and links with your own content."
    ],
    "html": "<footer class=\"rf-footer rf-container\"><div><strong>Studio</strong><p style=\"margin:.25rem 0\">© 2026 Your company</p></div><nav class=\"rf-nav\" aria-label=\"Footer links\"><a href=\"#about\">About</a><a href=\"#privacy\">Privacy</a><a href=\"#contact\">Contact</a></nav></footer>",
    "cssBytes": 2189
  },
  {
    "id": "contact",
    "title": "Contact form",
    "category": "Sections",
    "description": "A labelled native form layout, ready for your submission handler.",
    "css": [
      "sections",
      "card",
      "form",
      "button"
    ],
    "js": [],
    "file": "sections/contact.html",
    "notes": [
      "The gallery intercepts submissions and sends no data.",
      "Replace data-demo-form with your own action, method, and handler.",
      "Validate all submitted data on the server."
    ],
    "html": "<section class=\"rf-section rf-container\" id=\"contact\"><div class=\"rf-grid\"><div><p class=\"rf-eyebrow\">Start a conversation</p><h2 class=\"rf-section__heading\">Tell us what’s next.</h2><p class=\"rf-section__intro\">A sample form layout. Connect it to your own backend before publishing.</p></div><form class=\"rf-card rf-stack\" data-demo-form><div class=\"rf-field\"><label class=\"rf-label\" for=\"contact-name\">Name</label><input class=\"rf-input\" id=\"contact-name\" name=\"name\" autocomplete=\"name\" required></div><div class=\"rf-field\"><label class=\"rf-label\" for=\"contact-email\">Email</label><input class=\"rf-input\" id=\"contact-email\" type=\"email\" name=\"email\" autocomplete=\"email\" required></div><div class=\"rf-field\"><label class=\"rf-label\" for=\"contact-message\">Message</label><textarea class=\"rf-textarea\" id=\"contact-message\" name=\"message\" required></textarea></div><button class=\"rf-button\" type=\"submit\">Send message</button></form></div></section>",
    "cssBytes": 6523
  }
];
